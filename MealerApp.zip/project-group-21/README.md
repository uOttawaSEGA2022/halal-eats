# Group 21's Mealer App

Repository for the SEG2105 Mealer App project.

Group members:
Abdullah, Fatmah, Saba, Sophia, Solin

## Notes
The registration and login pages do have form checks but they won't show until the current form check errors displayed is fixed from user input, please keep that in mind. It basically does all the form checks :)
